#include "/home/echo/UAV_engi/src/lidar_slam/lidar_sim/include/lidar_sim/slam2px4.h"


using namespace bridge;

int main(int argc, char** argv) {
  ros::init(argc, argv, "slam2px4_node");
//   ros::NodeHandle nh("~");               /私有,参考命名空间与节点名称
  ros::NodeHandle nh;

  SLAM_PX4 Bridge(nh);

  ros::spin();

  Bridge.worker_.join();

  return 0;
}
