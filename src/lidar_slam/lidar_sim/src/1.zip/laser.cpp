#include <ros/ros.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <ros/ros.h>
#include "/home/echo/UAV_engi/devel/include/lidar_sim/shot.h"
#include "/home/echo/UAV_engi/devel/include/lidar_sim/yolo_msg.h"

#include <serial/serial.h> // 串口通信库头文件
using namespace std;
using namespace boost::asio;


io_service iosev;
serial_port sp(iosev, "/dev/ttyUSB0");

void shotCallback(const lidar_sim::shotConstPtr& msg)
{
//   std::string data = msg->data;
    int flag = msg->shot;
  ROS_INFO("Received shot: %d", msg->shot);
    std::string data = std::to_string(flag) + " ";
  write(sp, buffer(data.c_str(), data.size()));
}

int main(int argc, char* argv[])
{
  ros::init(argc, argv, "serial_node");
  ros::NodeHandle nh;

  sp.set_option(serial_port::baud_rate(115200));
  sp.set_option(serial_port::flow_control(serial_port::flow_control::none));
  sp.set_option(serial_port::parity(serial_port::parity::none));
  sp.set_option(serial_port::stop_bits(serial_port::stop_bits::one));
  sp.set_option(serial_port::character_size(8));

  ros::Subscriber sub = nh.subscribe("/data/shot", 10, shotCallback);

  ros::spin();

  return 0;
}
