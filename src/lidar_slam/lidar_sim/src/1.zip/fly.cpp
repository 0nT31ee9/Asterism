#include "/home/echo/UAV_engi/src/lidar_slam/lidar_sim/include/lidar_sim/fly.h"
// #include "/home/levelmoon/SLAM/PX4_frame/UAV_engi/devel/include/lidar_sim/arrive.h"
#include <std_msgs/Int32.h>

void Path::CmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg){
    double linear_x = msg->linear.x;
    double linear_y = msg->linear.y;
    double linear_z = msg->linear.z;
    double angular_z = msg->angular.z;

    PathTarget.position.z = 1;
    
    PathTarget.velocity.x = linear_x;
    PathTarget.velocity.y = linear_y;
    PathTarget.velocity.z = linear_z;
    PathTarget.yaw_rate = angular_z;

    PathTarget.coordinate_frame = PathTarget.FRAME_LOCAL_NED;
    // PathTarget.coordinate_frame = 1;

    PathTarget.type_mask = PathTarget.IGNORE_PX |
                           PathTarget.IGNORE_PY |
                        //    PathTarget.IGNORE_PZ |
                        //    PathTarget.IGNORE_VZ |
                           PathTarget.IGNORE_AFX|
                           PathTarget.IGNORE_AFY|
                           PathTarget.IGNORE_AFZ|
                           PathTarget.IGNORE_YAW;
    std::cout << "2222"  << std::endl;

}


void Path::PlanCallback(const nav_msgs::Path::ConstPtr& msg){
    if (!msg->poses.empty()){
        if (msg->poses.size() > 10){
            geometry_msgs::PoseStamped first_pose = msg->poses[10];
            // PlanTarget.yaw = yaw;
            PlanTarget.position.z = Z_target;
            PlanTarget.position.x = first_pose.pose.position.x;
            PlanTarget.position.y = first_pose.pose.position.y;

            // double yaw = tf::getYaw(first_pose.pose.orientation);
            // PlanTarget.yaw = yaw;
            // PlanTarget.position.z = first_pose.pose.position.z;
            PlanTarget.coordinate_frame=PositionTarget.FRAME_LOCAL_NED;
            PlanTarget.type_mask=PositionTarget.IGNORE_VX|
                                PositionTarget.IGNORE_VY|
                                PositionTarget.IGNORE_VZ|
                                PositionTarget.IGNORE_AFX|
                                PositionTarget.IGNORE_AFY|
                                PositionTarget.IGNORE_AFZ|
                                PositionTarget.IGNORE_YAW|
                                PositionTarget.IGNORE_YAW_RATE;
        }
        else{
            if (msg->poses.size() > 4){
                geometry_msgs::PoseStamped first_pose = msg->poses[msg->poses.size()/2];
                // PlanTarget.yaw = yaw;
                PlanTarget.position.z = Z_target;
                PlanTarget.position.x = first_pose.pose.position.x;
                PlanTarget.position.y = first_pose.pose.position.y;

                // double yaw = tf::getYaw(first_pose.pose.orientation);
                // PlanTarget.yaw = yaw;
                // PlanTarget.position.z = first_pose.pose.position.z;
                PlanTarget.coordinate_frame=PositionTarget.FRAME_LOCAL_NED;
                PlanTarget.type_mask=PositionTarget.IGNORE_VX|
                                    PositionTarget.IGNORE_VY|
                                    PositionTarget.IGNORE_VZ|
                                    PositionTarget.IGNORE_AFX|
                                    PositionTarget.IGNORE_AFY|
                                    PositionTarget.IGNORE_AFZ|
                                    PositionTarget.IGNORE_YAW|
                                    PositionTarget.IGNORE_YAW_RATE;
            }
            else{
                geometry_msgs::PoseStamped first_pose = msg->poses[msg->poses.size() - 1];
                // PlanTarget.yaw = yaw;
                PlanTarget.position.z = Z_target;
                PlanTarget.position.x = first_pose.pose.position.x;
                PlanTarget.position.y = first_pose.pose.position.y;

                // double yaw = tf::getYaw(first_pose.pose.orientation);
                // PlanTarget.yaw = yaw;
                // PlanTarget.position.z = first_pose.pose.position.z;
                PlanTarget.coordinate_frame=PositionTarget.FRAME_LOCAL_NED;
                PlanTarget.type_mask=PositionTarget.IGNORE_VX|
                                    PositionTarget.IGNORE_VY|
                                    PositionTarget.IGNORE_VZ|
                                    PositionTarget.IGNORE_AFX|
                                    PositionTarget.IGNORE_AFY|
                                    PositionTarget.IGNORE_AFZ|
                                    PositionTarget.IGNORE_YAW|
                                    PositionTarget.IGNORE_YAW_RATE;
            }
        }
    }
  
};
void Path::SetGoal(double x, double y,double z){
    goal.target_pose.header.frame_id = "map";  // 坐标系（frame_id）根据实际情况设置
    goal.target_pose.header.stamp = ros::Time::now();
    goal.target_pose.pose.position.x = x;    // 设置目标点的X坐标
    goal.target_pose.pose.position.y = y;    // 设置目标点的Y坐标
    goal.target_pose.pose.orientation.x = 0.0; // 设置目标点的姿态四元数
    goal.target_pose.pose.orientation.y = 0.0;
    goal.target_pose.pose.orientation.z = 0.0;
    goal.target_pose.pose.orientation.w = 1; // 设置目标点的姿态，这里是单位四元数表示

    ROS_INFO("发布导航目标点...");
    mbc_.sendGoal(goal);
}
//获取高度数据
void Path::altitudeCallback(const mavros_msgs::Altitude::ConstPtr& msg) {
    altitude.data = msg->local;
    // ROS_INFO("Current altitude: %.2f meters", altitude.data);
}

void Path::stateCallback(const mavros_msgs::State::ConstPtr& msg) {
    current_state = *msg;
}

void Path::localCallback(const geometry_msgs::PoseStamped::ConstPtr& msg){
    // 获取当前无人机的位置
    current_x = msg->pose.position.x;
    current_y = msg->pose.position.y;
    current_z = msg->pose.position.z;

    diss_x = PositionTarget.position.x - current_x;
    diss_y = PositionTarget.position.y - current_y;
    diss_z = PositionTarget.position.z - current_z;

    // yaw = msg->yaw;

    // 计算与目标位置的距离
    distance_to_target = std::sqrt(std::pow(PositionTarget.position.x - current_x, 2) + std::pow(PositionTarget.position.y - current_y, 2) + std::pow(PositionTarget.position.z - current_z, 2));

    // diss_A = std::sqrt(std::pow(3 - current_x, 2) + std::pow(3 - current_y, 2));
    diss_A = std::sqrt(std::pow( current_x + 3 , 2) + std::pow(current_y, 2));

    diss_B = std::sqrt(std::pow(current_x , 2) + std::pow(current_y, 2));

    
    std::cout << "diss:" << diss_A << std::endl;
    // 判断是否到达目标位置
    if (distance_to_target > (threshold + 0.1)) {
        // ROS_INFO("Arrived at target position!");
        // task+=1;
        // std::cout << "task:" << current_x << std::endl;
        is_distance_updated = true;
    }
    // is_distance_updated = true;
}


void Path::arm() {
    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;
    if (arming_client.call(arm_cmd) && arm_cmd.response.success) 
    {
        ROS_INFO("Vehicle D, success=%d", arm_cmd.response.success);
    }
    else
    {
        ROS_ERROR("Failed to arm vehicle");
        ROS_ERROR("Failed to arm vehicle, success=%d", arm_cmd.response.success);
    }
}

void Path::disarm() {
    mavros_msgs::CommandBool disarm_cmd;
    disarm_cmd.request.value = false;
    if (arming_client.call(disarm_cmd) && disarm_cmd.response.success) {
        ROS_INFO("Vehicle disarmed");
    }
    else {
        ROS_ERROR("Failed to disarm vehicle");
        }
}

void Path::setMode(std::string mode) {
    mavros_msgs::SetMode set_mode_cmd;
    set_mode_cmd.request.custom_mode = mode;
    if (set_mode_client.call(set_mode_cmd) && set_mode_cmd.response.mode_sent) {
        // ROS_INFO_STREAM("Mode changed to " << mode);
    }
    else {
        ROS_ERROR("Failed to set mode");
    }
}


std::pair<double, double> Path::TaskDetection(int target_id)
{
    for (const auto& object : object_map)
    {
        int id = object.first;
        double cx = object.second.first;
        double cy = object.second.second;

        if (id == target_id)
        {
            return std::make_pair(cx, cy);
        }
    }

    return std::make_pair(640.0, 360.0);
}


//起飞
void Path::_Fly(){
    PositionTarget.position.x=0;
    PositionTarget.position.y=0;    //修改
    PositionTarget.position.z=Z_target;
    PositionTarget.coordinate_frame=PositionTarget.FRAME_LOCAL_NED;
    PositionTarget.type_mask=PositionTarget.IGNORE_VX|PositionTarget.IGNORE_VY|PositionTarget.IGNORE_VZ|PositionTarget.IGNORE_AFX|PositionTarget.IGNORE_AFY|PositionTarget.IGNORE_AFZ|PositionTarget.IGNORE_YAW|PositionTarget.IGNORE_YAW_RATE;
}

void Path::fixed()
{
    PositionTarget.position.x=-3;
    PositionTarget.position.y=0;
    PositionTarget.position.z = Z_target;

    // PositionTarget.yaw = yawValue;  // 设置偏航角度为π弧度，即180度
    // PositionTarget.yaw_rate =  M_PI / 3;
    PositionTarget.coordinate_frame = PositionTarget.FRAME_LOCAL_NED;
    PositionTarget.type_mask=PositionTarget.IGNORE_VX|
    PositionTarget.IGNORE_VY|PositionTarget.IGNORE_VZ|
    PositionTarget.IGNORE_AFX|PositionTarget.IGNORE_AFY|
    PositionTarget.IGNORE_AFZ|
    PositionTarget.IGNORE_YAW;
    PositionTarget.IGNORE_YAW_RATE;
}

void Path::run()
{ 
    // 设置控制频率
    ros::Rate rate(20.0);
    
    // 等待飞控连接
    while (ros::ok() && !current_state.connected) {
        std::cout << "WAITING FOR connected" << std::endl;

        ros::spinOnce();
        rate.sleep();
    }

    // 发送空速度控制指令
    _Fly();
    // path_pub.publish(PositionTarget);

    // 切换到offboard模式
    while (ros::ok() && (current_state.mode != "OFFBOARD")) {
        std::cout << "WAITING FOR OFFBOARD" << std::endl;
        path_pub.publish(PositionTarget);
        setMode("OFFBOARD");
        ros::spinOnce();
        rate.sleep();
    }

    // 解锁
    // 等待解锁完成
    while (ros::ok() && !current_state.armed) {
        arm();
        ros::Duration(2).sleep();
        std::cout << "WAITING FOR ARMED" << std::endl;
        ros::spinOnce();
        rate.sleep();
    }

    start_time = ros::Time::now().toSec();

    while(ros::ok()){
        switch(FlyState)
        {
            case Fly:
                _Fly();
                FlyState = Fly;
                // if (distance_to_target < threshold)
                // if (distance_to_target < 0.16 && diss_y < 0.03 && diss_z < 0.02) 

                path_pub.publish(PositionTarget);
                if (distance_to_target < 0.16 && diss_z < 0.02) 
                {
                    // FlyState = Pub_A;
                    // setMode("AUTO.LAND");
                std::cout << "ok" << std::endl;

                }
                std::cout << "Flying2222" << std::endl;
                break;

            // case Pub_A:
            //     SetGoal(-3, 0, 1.0);
            //     FlyState = Move_A;
            //     std::cout << "Pub_A" << std::endl;


            // case Move_A:
            //     FlyState = Move_A;
            //     // std::cout << "Before checking distance: is_distance_updated=" << is_distance_updated << ", distance_to_target=" << distance_to_target << std::endl;
            //     // if ((distance_to_target < threshold) && is_distance_updated) 
            //     // {
            //     //     ROS_INFO("Arrived at D position!");
            //     //     FlyState = grap;
            //     //     is_distance_updated = false;
            //     // }

            //     // 修改
            //     path_pub.publish(PlanTarget);
            //     if (diss_A < 0.1)
            //     {
            //         fixed();
            //         path_pub.publish(PositionTarget);
            //         FlyState = Fixed_A;
            //         std::cout << "error" << std::endl;

            //     }
            //     // if (diss_A < 0.1){
            //     //     setMode("AUTO.LAND");
            //     //     std::cout << "LAND" << std::endl;

            //     // }
            //     std::cout << "Move_A" << std::endl;
            //     start_time = ros::Time::now().toSec();
            //     break;
            // case Fixed_A:
            //     path_pub.publish(PositionTarget);
            //     FlyState = Fixed_A;
            //     std::cout << "Fixed_A" << std::endl;
            //     current_time = ros::Time::now().toSec();
            //     elapsed_time = current_time - start_time;
            //     if (elapsed_time >= 2.0){

            //         SetGoal(0, 0, 1.0);
            //         FlyState = Move_B;
            //         path_pub.publish(PlanTarget);
            //     }
            //     break;
            // case Move_B:
            //     FlyState = Move_B;
            //     path_pub.publish(PlanTarget);
            //     std::cout << "Move_B" << std::endl;
                
            //     if (diss_B < 0.15 && current_x < 0.04){
            //         FlyState = Land;
            //         std::cout << "Land!" << std::endl;
            //     }
            //     break;
            // case Land:
            //     // while (ros::ok() && (current_state.mode != "OFFBOARD"))
            //     setMode("AUTO.LAND");
            //     FlyState = Land;
            //     std::cout << "Land!" << std::endl;
            //     break;
        }
        // path_pub.publish(PathTarget);
            ros::spinOnce();
            rate.sleep();
        }
        // spinThread.join();
        // 关闭飞行模式和解锁
        setMode("MANUAL");
        disarm();
}

int main(int argc, char** argv)
{
    // 初始化ROS节点
    ros::init(argc, argv, "path_publisher");

    Path path;
    path.run();

    return 0;
}
