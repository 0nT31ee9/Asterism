#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>

ros::Publisher odom_pub;
nav_msgs::Odometry odom;
double Z_VALUE = 0.0;
void truthCallback(const nav_msgs::Odometry& msg)
{
    Z_VALUE = msg.pose.pose.position.z;
}

// 回调函数将执行每次PoseStamped消息到达时
void poseCallback(const geometry_msgs::PoseStampedConstPtr& msg)
{

    odom.header.stamp = msg->header.stamp;
    odom.header.frame_id = "odom"; // Or whatever your odometry frame is

    odom.pose.pose = msg->pose;
    odom.pose.pose.position.z = Z_VALUE;

    // Assuming we don't have any velocity information, we can just set these to zero
    odom.child_frame_id = msg->header.frame_id;
    odom.twist.twist.linear.x = 0;
    odom.twist.twist.linear.y = 0;
    odom.twist.twist.linear.z = 0;
    odom.twist.twist.angular.x = 0;
    odom.twist.twist.angular.y = 0;
    odom.twist.twist.angular.z = 0;

    // odom_pub.publish(odom);

}

void timerCallback(const ros::TimerEvent&)
{
    odom_pub.publish(odom);
}

int main(int argc, char **argv)
{
    // 初始化ROS节点
    ros::init(argc, argv, "odom_pub_from_pose");
    ros::NodeHandle nh;

    std::string sub_slam_topic_, sub_truth_topic_, odom_pub_topic_;
    nh.param<std::string>("/sub_slam_topic_", sub_slam_topic_, "/slam_out_pose");
    nh.param<std::string>("/sub_truth_topic_", sub_truth_topic_, "/iris_0/ground_truth/state");
    nh.param<std::string>("/odom_pub_topic_", odom_pub_topic_, "/slam2odom");


    ros::Subscriber sub_slam = nh.subscribe(sub_slam_topic_, 10, poseCallback);
    ros::Subscriber sub_truth = nh.subscribe(sub_truth_topic_, 10, truthCallback);

    ros::Timer timer = nh.createTimer(ros::Duration(1.0/120), timerCallback);
    odom_pub = nh.advertise<nav_msgs::Odometry>(odom_pub_topic_, 10);

    ros::spin();
}