#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_datatypes.h>
#include <cmath>

void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg)
{
  // 获取四元数姿态数据
  geometry_msgs::Quaternion quaternion = msg->pose.orientation;

  // 使用tf库中的转换函数将四元数转换为欧拉角
  tf::Quaternion tfQuaternion;
  tf::quaternionMsgToTF(quaternion, tfQuaternion);
  double roll, pitch, yaw;
  tf::Matrix3x3(tfQuaternion).getRPY(roll, pitch, yaw);

  // 将弧度制转换为角度制
  double yaw_deg = yaw * (180.0 / M_PI);

  // 输出yaw轴角度
  ROS_INFO("Yaw: %f degrees", yaw_deg);
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "quat_to_yaw_node");
  ros::NodeHandle nh;

  // 订阅/mavros/local_position/pose话题的消息
  ros::Subscriber sub = nh.subscribe("/mavros/local_position/pose", 10, poseCallback);

  ros::spin();

  return 0;
}
